import { ShieldCheck, Leaf, Heart, Sparkles, Check } from 'lucide-react';
import { Button } from './components/ui/button';
import { Card, CardContent } from './components/ui/card';
import { Badge } from './components/ui/badge';
import heroImage from '../imports/WhatsApp_Image_2026-04-21_at_13.38.31.jpeg';
import productImage from '../imports/WhatsApp_Image_2026-04-21_at_13.37.28.jpeg';
import logoFull from '../imports/Screen_Shot_2024-06-09_at_2.11.26_PM.png';
import logoText from '../imports/Screen_Shot_2024-06-09_at_3.04.30_PM.png';
import logoTextLight from '../imports/Screen_Shot_2024-06-10_at_4.05.39_PM.png';

export default function App() {
  const STRIPE_CHECKOUT_URL = 'https://buy.stripe.com/test_00w5kE14vdOI8wU4Sbak000';

  const scrollToSection = (id: string) => {
    const element = document.getElementById(id);
    if (element) {
      element.scrollIntoView({ behavior: 'smooth', block: 'start' });
    }
  };

  const handleCheckout = () => {
    // Open Stripe checkout in new tab
    window.open(STRIPE_CHECKOUT_URL, '_blank');
  };

  return (
    <div className="min-h-screen bg-gradient-to-b from-white to-[#F1F8F1]">
      {/* Navigation */}
      <nav className="sticky top-0 z-50 bg-white/95 backdrop-blur-md border-b border-[#D7E5D7]">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            <div className="flex items-center">
              <img src={logoFull} alt="SanaVieta" className="h-14 w-auto" />
            </div>
            <div className="hidden md:flex items-center gap-8">
              <button
                onClick={() => scrollToSection('benefits')}
                className="text-[#3E5A3E] hover:text-[#2E7D32] transition-colors"
              >
                Benefits
              </button>
              <button
                onClick={() => scrollToSection('products')}
                className="text-[#3E5A3E] hover:text-[#2E7D32] transition-colors"
              >
                Products
              </button>
              <button
                onClick={() => scrollToSection('about')}
                className="text-[#3E5A3E] hover:text-[#2E7D32] transition-colors"
              >
                Our Story
              </button>
            </div>
            <Button
              onClick={handleCheckout}
              className="bg-[#4CAF50] hover:bg-[#2E7D32] text-white"
            >
              Shop Now
            </Button>
          </div>
        </div>
      </nav>

      {/* Hero Section */}
      <section className="container mx-auto px-4 sm:px-6 lg:px-8 py-12 md:py-20">
        <div className="grid lg:grid-cols-2 gap-12 items-center">
          <div className="space-y-6">
            <Badge className="bg-[#E8F5E9] text-[#1B5E20] border-[#C8E6C9] hover:bg-[#E8F5E9]">
              Natural Wellness Solutions
            </Badge>
            <h1 className="text-4xl md:text-5xl lg:text-6xl font-bold text-[#1B5E20] leading-tight">
              Discover Pure, Natural Solutions for Your Vibrant Life
            </h1>
            <p className="text-lg text-[#3E5A3E] leading-relaxed">
              Premium lymphatic system support designed for adults seeking comfort, vitality, and natural wellness through scientifically-backed herbal formulations.
            </p>
            <div className="flex flex-col sm:flex-row gap-4">
              <Button
                size="lg"
                onClick={() => scrollToSection('products')}
                className="bg-[#4CAF50] hover:bg-[#2E7D32] text-white px-8 h-12"
              >
                Explore Products
              </Button>
              <Button
                size="lg"
                variant="outline"
                onClick={() => scrollToSection('about')}
                className="border-[#4CAF50] text-[#2E7D32] hover:bg-[#E8F5E9] h-12"
              >
                Learn More
              </Button>
            </div>
            <div className="flex flex-wrap gap-6 pt-4">
              <div className="flex items-center gap-2">
                <ShieldCheck className="w-5 h-5 text-[#4CAF50]" />
                <span className="text-sm text-[#3E5A3E]">Made in USA</span>
              </div>
              <div className="flex items-center gap-2">
                <ShieldCheck className="w-5 h-5 text-[#4CAF50]" />
                <span className="text-sm text-[#3E5A3E]">GMP Certified</span>
              </div>
              <div className="flex items-center gap-2">
                <ShieldCheck className="w-5 h-5 text-[#4CAF50]" />
                <span className="text-sm text-[#3E5A3E]">Third-Party Tested</span>
              </div>
            </div>
          </div>
          <div className="relative">
            <div className="absolute inset-0 bg-gradient-to-br from-[#E8F5E9] to-transparent rounded-3xl -rotate-3"></div>
            <img
              src={heroImage}
              alt="SanaVieta Lymphatic Support Supplements"
              className="relative rounded-2xl shadow-2xl w-full"
            />
          </div>
        </div>
      </section>

      {/* Brand Showcase */}
      <section className="py-12 border-y border-[#D7E5D7]">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex flex-col items-center justify-center gap-8">
            <div className="text-center">
              <img src={logoText} alt="SanaVieta" className="h-12 md:h-16 w-auto mx-auto mb-4" />
              <p className="text-sm text-[#6B7D6B] uppercase tracking-wider">
                Naturopathic Wellness • Radical Transparency
              </p>
            </div>
            <div className="grid grid-cols-2 md:grid-cols-4 gap-8 md:gap-12 text-center">
              <div>
                <p className="text-3xl md:text-4xl font-bold text-[#1B5E20]">100%</p>
                <p className="text-sm text-[#6B7D6B] mt-1">Natural</p>
              </div>
              <div>
                <p className="text-3xl md:text-4xl font-bold text-[#1B5E20]">GMP</p>
                <p className="text-sm text-[#6B7D6B] mt-1">Certified</p>
              </div>
              <div>
                <p className="text-3xl md:text-4xl font-bold text-[#1B5E20]">USA</p>
                <p className="text-sm text-[#6B7D6B] mt-1">Made</p>
              </div>
              <div>
                <p className="text-3xl md:text-4xl font-bold text-[#1B5E20]">180</p>
                <p className="text-sm text-[#6B7D6B] mt-1">Day Guarantee</p>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Benefits Section */}
      <section id="benefits" className="bg-white py-16 md:py-24">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <Badge className="bg-[#E8F5E9] text-[#1B5E20] border-[#C8E6C9] hover:bg-[#E8F5E9] mb-4">
              Why Choose SanaVieta
            </Badge>
            <h2 className="text-3xl md:text-4xl font-bold text-[#1B5E20] mb-4">
              Natural Support for Your Well-Being
            </h2>
            <p className="text-lg text-[#3E5A3E] max-w-2xl mx-auto">
              Experience the difference that pure, scientifically-backed ingredients can make in your daily comfort and vitality
            </p>
          </div>

          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
            <Card className="border-[#D7E5D7] hover:shadow-lg transition-shadow">
              <CardContent className="pt-6">
                <div className="w-12 h-12 bg-[#E8F5E9] rounded-xl flex items-center justify-center mb-4">
                  <Heart className="w-6 h-6 text-[#2E7D32]" />
                </div>
                <h3 className="font-semibold text-[#1B5E20] mb-2">Circulation Support</h3>
                <p className="text-sm text-[#3E5A3E]">
                  Support healthy fluid movement throughout your body for optimal comfort
                </p>
              </CardContent>
            </Card>

            <Card className="border-[#D7E5D7] hover:shadow-lg transition-shadow">
              <CardContent className="pt-6">
                <div className="w-12 h-12 bg-[#E8F5E9] rounded-xl flex items-center justify-center mb-4">
                  <ShieldCheck className="w-6 h-6 text-[#2E7D32]" />
                </div>
                <h3 className="font-semibold text-[#1B5E20] mb-2">Immune Foundation</h3>
                <p className="text-sm text-[#3E5A3E]">
                  Your lymphatic system is the backbone of your body's natural defenses
                </p>
              </CardContent>
            </Card>

            <Card className="border-[#D7E5D7] hover:shadow-lg transition-shadow">
              <CardContent className="pt-6">
                <div className="w-12 h-12 bg-[#E8F5E9] rounded-xl flex items-center justify-center mb-4">
                  <Sparkles className="w-6 h-6 text-[#2E7D32]" />
                </div>
                <h3 className="font-semibold text-[#1B5E20] mb-2">Enhanced Vitality</h3>
                <p className="text-sm text-[#3E5A3E]">
                  Feel the energy that comes when your body flows freely and naturally
                </p>
              </CardContent>
            </Card>

            <Card className="border-[#D7E5D7] hover:shadow-lg transition-shadow">
              <CardContent className="pt-6">
                <div className="w-12 h-12 bg-[#E8F5E9] rounded-xl flex items-center justify-center mb-4">
                  <Leaf className="w-6 h-6 text-[#2E7D32]" />
                </div>
                <h3 className="font-semibold text-[#1B5E20] mb-2">Natural Ingredients</h3>
                <p className="text-sm text-[#3E5A3E]">
                  Pure, carefully selected botanicals backed by traditional wisdom and research
                </p>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      {/* Featured Product Section */}
      <section id="products" className="py-16 md:py-24">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid lg:grid-cols-2 gap-12 items-center">
            <div className="order-2 lg:order-1">
              <img
                src={productImage}
                alt="SanaLymph - Lymphatic System & Vascular Support"
                className="rounded-2xl shadow-2xl w-full"
              />
            </div>
            <div className="order-1 lg:order-2 space-y-6">
              <Badge className="bg-[#FFF8E1] text-[#8D6E00] border-[#FFE082] hover:bg-[#FFF8E1]">
                Featured Product
              </Badge>
              <h2 className="text-3xl md:text-4xl font-bold text-[#1B5E20]">
                SanaLymph™
              </h2>
              <p className="text-xl text-[#2E7D32] font-semibold">
                Lymphatic System & Vascular Support
              </p>
              <p className="text-[#3E5A3E] leading-relaxed">
                Our flagship formula combines micronized Diosmin, enteric-coated Bromelain, Horse Chestnut & Butcher's Broom, Gotu Kola, and Selenium for superior bioavailability and targeted relief.
              </p>

              <div className="space-y-3">
                <div className="flex items-start gap-3">
                  <Check className="w-5 h-5 text-[#4CAF50] mt-0.5 flex-shrink-0" />
                  <p className="text-[#3E5A3E]"><span className="font-semibold">Micronized Diosmin 600mg</span> - Enhanced absorption</p>
                </div>
                <div className="flex items-start gap-3">
                  <Check className="w-5 h-5 text-[#4CAF50] mt-0.5 flex-shrink-0" />
                  <p className="text-[#3E5A3E]"><span className="font-semibold">Enteric-Coated Bromelain 150mg</span> - Stomach-friendly</p>
                </div>
                <div className="flex items-start gap-3">
                  <Check className="w-5 h-5 text-[#4CAF50] mt-0.5 flex-shrink-0" />
                  <p className="text-[#3E5A3E]"><span className="font-semibold">Vascular Integrity Support</span> - Edema reduction</p>
                </div>
                <div className="flex items-start gap-3">
                  <Check className="w-5 h-5 text-[#4CAF50] mt-0.5 flex-shrink-0" />
                  <p className="text-[#3E5A3E]"><span className="font-semibold">60 Capsules</span> - 30-day supply</p>
                </div>
              </div>

              <div className="flex items-baseline gap-4">
                <span className="text-4xl font-bold text-[#1B5E20]">$69</span>
                <span className="text-[#6B7D6B]">per bottle</span>
              </div>

              <Button
                size="lg"
                onClick={handleCheckout}
                className="bg-[#4CAF50] hover:bg-[#2E7D32] text-white w-full sm:w-auto px-8 h-12"
              >
                Add to Cart
              </Button>

              <div className="flex items-center gap-2 text-sm text-[#3E5A3E] pt-4">
                <ShieldCheck className="w-5 h-5 text-[#4CAF50]" />
                <span>180-Day Money-Back Guarantee</span>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* About Section */}
      <section id="about" className="bg-gradient-to-br from-[#E8F5E9] to-white py-16 md:py-24">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <div className="max-w-4xl mx-auto">
            <div className="text-center mb-12">
              <h2 className="text-3xl md:text-4xl font-bold text-[#1B5E20] mb-4">
                Senior Wellness Through Radical Transparency
              </h2>
              <p className="text-lg text-[#3E5A3E] leading-relaxed">
                At SanaVieta, we believe in naturopathic wellness backed by science and delivered with complete transparency.
                Every ingredient is carefully selected, every claim is substantiated, and every bottle is crafted with your
                well-being in mind.
              </p>
            </div>

            <div className="grid md:grid-cols-3 gap-8 mt-12">
              <Card className="border-[#D7E5D7] bg-white/80 backdrop-blur">
                <CardContent className="pt-6 text-center">
                  <div className="w-12 h-12 bg-[#4CAF50] rounded-full flex items-center justify-center mx-auto mb-4">
                    <Leaf className="w-6 h-6 text-white" />
                  </div>
                  <h3 className="font-semibold text-[#1B5E20] mb-2">Natural First</h3>
                  <p className="text-sm text-[#3E5A3E]">
                    Pure botanical ingredients sourced with care and formulated for maximum efficacy
                  </p>
                </CardContent>
              </Card>

              <Card className="border-[#D7E5D7] bg-white/80 backdrop-blur">
                <CardContent className="pt-6 text-center">
                  <div className="w-12 h-12 bg-[#4CAF50] rounded-full flex items-center justify-center mx-auto mb-4">
                    <ShieldCheck className="w-6 h-6 text-white" />
                  </div>
                  <h3 className="font-semibold text-[#1B5E20] mb-2">Science Backed</h3>
                  <p className="text-sm text-[#3E5A3E]">
                    Every formulation is supported by published research and third-party testing
                  </p>
                </CardContent>
              </Card>

              <Card className="border-[#D7E5D7] bg-white/80 backdrop-blur">
                <CardContent className="pt-6 text-center">
                  <div className="w-12 h-12 bg-[#4CAF50] rounded-full flex items-center justify-center mx-auto mb-4">
                    <Heart className="w-6 h-6 text-white" />
                  </div>
                  <h3 className="font-semibold text-[#1B5E20] mb-2">Your Vitality</h3>
                  <p className="text-sm text-[#3E5A3E]">
                    Dedicated to helping you maintain independence and quality of life at every age
                  </p>
                </CardContent>
              </Card>
            </div>
          </div>
        </div>
      </section>

      {/* Trust Section */}
      <section className="bg-[#1B5E20] text-white py-16 md:py-20">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="text-3xl md:text-4xl font-bold mb-4">
              Committed to Excellence
            </h2>
            <p className="text-lg text-[#E8F5E9] max-w-2xl mx-auto">
              Every bottle meets the highest standards of quality, purity, and transparency
            </p>
          </div>

          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
            <div className="text-center">
              <div className="w-16 h-16 bg-[#4CAF50] rounded-full flex items-center justify-center mx-auto mb-4">
                <ShieldCheck className="w-8 h-8 text-white" />
              </div>
              <h3 className="font-semibold mb-2">Made in USA</h3>
              <p className="text-sm text-[#E8F5E9]">
                Manufactured in GMP-certified facilities
              </p>
            </div>

            <div className="text-center">
              <div className="w-16 h-16 bg-[#4CAF50] rounded-full flex items-center justify-center mx-auto mb-4">
                <ShieldCheck className="w-8 h-8 text-white" />
              </div>
              <h3 className="font-semibold mb-2">Third-Party Tested</h3>
              <p className="text-sm text-[#E8F5E9]">
                Independent lab verification for purity
              </p>
            </div>

            <div className="text-center">
              <div className="w-16 h-16 bg-[#4CAF50] rounded-full flex items-center justify-center mx-auto mb-4">
                <Leaf className="w-8 h-8 text-white" />
              </div>
              <h3 className="font-semibold mb-2">Natural Ingredients</h3>
              <p className="text-sm text-[#E8F5E9]">
                Pure botanicals, no artificial additives
              </p>
            </div>

            <div className="text-center">
              <div className="w-16 h-16 bg-[#4CAF50] rounded-full flex items-center justify-center mx-auto mb-4">
                <Heart className="w-8 h-8 text-white" />
              </div>
              <h3 className="font-semibold mb-2">Satisfaction Guaranteed</h3>
              <p className="text-sm text-[#E8F5E9]">
                180-day money-back guarantee
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-16 md:py-24">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <Card className="border-[#4CAF50] border-2 overflow-hidden">
            <CardContent className="p-8 md:p-12 text-center">
              <h2 className="text-3xl md:text-4xl font-bold text-[#1B5E20] mb-4">
                Ready to Feel the Difference?
              </h2>
              <p className="text-lg text-[#3E5A3E] mb-8 max-w-2xl mx-auto">
                Join thousands who have discovered natural comfort and vitality through SanaVieta's premium formulations
              </p>
              <div className="flex flex-col sm:flex-row gap-4 justify-center">
                <Button
                  size="lg"
                  onClick={handleCheckout}
                  className="bg-[#4CAF50] hover:bg-[#2E7D32] text-white px-8 h-12"
                >
                  Shop Now
                </Button>
                <Button size="lg" variant="outline" className="border-[#4CAF50] text-[#2E7D32] hover:bg-[#E8F5E9] h-12">
                  Contact Us
                </Button>
              </div>
              <p className="text-sm text-[#6B7D6B] mt-6">
                Free shipping on all orders • 180-Day Money-Back Guarantee
              </p>
            </CardContent>
          </Card>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-[#1B5E20] text-white py-12">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid md:grid-cols-4 gap-8 mb-8">
            <div>
              <div className="mb-4">
                <img src={logoTextLight} alt="SanaVieta" className="h-8 w-auto brightness-0 invert" />
              </div>
              <p className="text-sm text-[#E8F5E9]">
                Natural wellness solutions for your vibrant life
              </p>
            </div>
            <div>
              <h4 className="font-semibold mb-4">Shop</h4>
              <ul className="space-y-2 text-sm text-[#E8F5E9]">
                <li><a href="#" className="hover:text-white transition-colors">All Products</a></li>
                <li><a href="#" className="hover:text-white transition-colors">Best Sellers</a></li>
                <li><a href="#" className="hover:text-white transition-colors">Bundles</a></li>
              </ul>
            </div>
            <div>
              <h4 className="font-semibold mb-4">Support</h4>
              <ul className="space-y-2 text-sm text-[#E8F5E9]">
                <li><a href="#" className="hover:text-white transition-colors">Contact Us</a></li>
                <li><a href="#" className="hover:text-white transition-colors">FAQ</a></li>
                <li><a href="#" className="hover:text-white transition-colors">Shipping</a></li>
                <li><a href="#" className="hover:text-white transition-colors">Returns</a></li>
              </ul>
            </div>
            <div>
              <h4 className="font-semibold mb-4">Company</h4>
              <ul className="space-y-2 text-sm text-[#E8F5E9]">
                <li><a href="#" className="hover:text-white transition-colors">About Us</a></li>
                <li><a href="#" className="hover:text-white transition-colors">Our Story</a></li>
                <li><a href="#" className="hover:text-white transition-colors">Quality</a></li>
              </ul>
            </div>
          </div>
          <div className="border-t border-[#4CAF50] pt-8 text-center">
            <p className="text-sm text-[#E8F5E9]">
              © 2026 SanaVieta. All rights reserved. These statements have not been evaluated by the FDA.
              This product is not intended to diagnose, treat, cure, or prevent any disease.
            </p>
          </div>
        </div>
      </footer>
    </div>
  );
}
